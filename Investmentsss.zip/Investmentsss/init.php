<?php 

// Routes of Header 

$css = "layouts/css/";



// Routes of Footer 

$js = "layouts/js/";



// Routes of Templates 

$tpl = "includes/templates/";