<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>HomePage</title>
		<link rel="stylesheet" href="<?php echo $css;  ?>bootstrap.css">
		<link rel="stylesheet" href="<?php echo $css;  ?>font-awesome.css">
		<link rel="stylesheet" href="<?php echo $css;  ?>front.css">
		<link rel="stylesheet" href="<?php echo $css;  ?>daterangepicker.css">
	</head>
	<body>